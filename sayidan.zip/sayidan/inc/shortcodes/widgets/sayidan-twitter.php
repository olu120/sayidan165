<?php 
if ( $instance['visibility'] != 1 ){
  	echo do_shortcode( '[sayidan_twitter ]' ); 	
}
?>